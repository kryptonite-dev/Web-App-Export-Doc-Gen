# Export Docs Webapp (Quotation & Invoice)
React + Vite + TypeScript + @react-pdf/renderer

## Quick Start
```bash
npm install
npm run dev
```

## GitHub + VS Code workflow
1. Create a new GitHub repo (empty).
2. In VS Code: `File > Open Folder...` and open this folder.
3. Initialize git and push:
   ```bash
   git init
   git add -A
   git commit -m "feat: export docs webapp mvp"
   git branch -M main
   git remote add origin <YOUR_GITHUB_REPO_URL>
   git push -u origin main
   ```

## Build
```bash
npm run build
npm run preview
```

## Notes
- PDF export requires the CSP in `index.html` that allows `wasm-unsafe-eval`.
- Google Drive/Sheets are stubs; wire OAuth 2.0 and API calls later.
