import React, { useEffect, useMemo, useState } from 'react';
import { Document, Page, Text, View, StyleSheet, pdf } from '@react-pdf/renderer';
import { Download, Plus, Trash2, FileText, History, FileSignature, FileCheck2 } from 'lucide-react';

type Currency = 'USD' | 'THB' | 'EUR' | 'AED' | string;
type Money = { currency: Currency; value: number };
type Party = { name: string; address: string };

export type LineItem = { description: string; unit: string; qty: number; unitPrice: Money; };

export type CommonDoc = {
  docType: 'Quotation' | 'Invoice';
  docNo?: string;
  subject: string;
  docDate: string;
  pages?: string;
  seller: Party;
  buyer: Party;
  attn: string;
  fromPerson: string;
  deliveryTerms: string;
  brand?: string;
  price?: Money;
  minOrderQty?: { value: number; unit: string };
  paymentTerms: string;
  sellerBank?: string;
  fxRate?: number;
  closing?: string;
  shippingMark?: string;
  items: LineItem[];
  subTotal?: Money; grandTotal?: Money;
  notes?: string[];
  drivePdfUrl?: string; sheetRowId?: string;
  exchangeCurrency?: Currency;
};

const ivory = '#FAFAF5';

const incoterms = [
  'FOB BANGKOK, THAILAND (Incoterms 2020)',
  'CFR MUMBAI, INDIA (Incoterms 2020)',
  'CIF DUBAI, UAE (Incoterms 2020)',
  'EXW SAMUT SAKHON, THAILAND (Incoterms 2020)',
];

const paymentPresets = [ '100% Advance Payment', 'TT within 30 days', 'LC at sight' ];

function fmt(n: number, digits = 2, locale = 'en-US') {
  if (!Number.isFinite(n)) return '0';
  return new Intl.NumberFormat(locale, { minimumFractionDigits: digits, maximumFractionDigits: digits }).format(n);
}
function fmtMoney(m: Money, locale = 'en-US') { return `${m.currency} ${fmt(m.value, 2, locale)}`; }
function wordsAmount(m: Money) { return `${m.currency} ${fmt(m.value)} only`; }
function todayISO() { const d=new Date(); const off=d.getTimezoneOffset(); const local = new Date(d.getTime()-off*60000); return local.toISOString().slice(0,10); }
function computeTotals(items: LineItem[], currency: Currency='USD'){ const sub=items.reduce((a,it)=>a+(it.qty||0)*(it.unitPrice?.value||0),0); return { subTotal:{currency,value:sub}, grandTotal:{currency,value:sub} }}

const STORAGE_KEY='export-docs-mvp-v1';
async function googleSignIn(){ alert('Google Sign-In: TODO') }
async function saveRowToSheets(_doc: CommonDoc){ alert('Save to Google Sheets: TODO'); return { sheetRowId: 'ROW-FAKE' } }
async function uploadPdfToDrive(_blob: Blob, _filename: string){ alert('Upload PDF to Google Drive: TODO'); return { webViewLink: undefined as string | undefined } }

const pdfStyles = StyleSheet.create({
  page: { padding: 28, fontSize: 10 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  title: { fontSize: 16, textAlign: 'center', marginVertical: 8 },
  label: { fontWeight: 'bold' },
  block: { marginBottom: 6 },
  line: { flexDirection: 'row', gap: 6, marginBottom: 2, flexWrap: 'wrap' },
  table: { marginTop: 8, borderTopWidth: 1, borderColor: '#999' },
  tr: { flexDirection: 'row', borderBottomWidth: 1, borderColor: '#ddd' },
  th: { padding: 4, fontWeight: 'bold', backgroundColor: '#f2f2f2' },
  td: { padding: 4 },
  colDesc: { width: '44%' }, colUnit: { width: '12%', textAlign: 'center' }, colQty: { width: '12%', textAlign: 'right' }, colPrice: { width: '16%', textAlign: 'right' }, colAmt: { width: '16%', textAlign: 'right' },
  summary: { marginTop: 8, alignItems: 'flex-end' },
  footer: { position: 'absolute', bottom: 20, left: 28, right: 28, fontSize: 9, color: '#666' },
});

function QuotationInvoicePDF({ doc }: { doc: CommonDoc }) {
  const { items } = doc;
  const totals = computeTotals(items, doc.exchangeCurrency || (items[0]?.unitPrice?.currency || 'USD'));
  return (
    <Document>
      <Page size='A4' style={pdfStyles.page} wrap>
        <View style={pdfStyles.headerRow}>
          <View><Text style={pdfStyles.label}>{doc.seller.name}</Text><Text>{doc.seller.address}</Text></View>
          <View><Text>DATE: {doc.docDate}</Text><Text>PAGES: 1 of 1</Text></View>
        </View>
        <Text style={pdfStyles.title}>{doc.docType.toUpperCase()}</Text>

        <View style={pdfStyles.block}>
          <View style={pdfStyles.line}><Text style={pdfStyles.label}>SELLER :</Text><Text>{doc.seller.name}, {doc.seller.address}</Text></View>
          <View style={pdfStyles.line}><Text style={pdfStyles.label}>TO :</Text><Text>{doc.buyer.name}, {doc.buyer.address}</Text></View>
          <View style={pdfStyles.line}><Text style={pdfStyles.label}>ATTN :</Text><Text>{doc.attn}</Text></View>
          <View style={pdfStyles.line}><Text style={pdfStyles.label}>FROM :</Text><Text>{doc.fromPerson}</Text></View>
          <View style={pdfStyles.line}><Text style={pdfStyles.label}>SUBJECT :</Text><Text>{doc.subject}</Text></View>
          <View style={pdfStyles.line}><Text style={pdfStyles.label}>{doc.docType==='Quotation'?'OUR REF.':'INVOICE NO.'} :</Text><Text>{doc.docNo || '-'}</Text></View>
          <View style={pdfStyles.line}><Text style={pdfStyles.label}>TERM OF DELIVERY :</Text><Text>{doc.deliveryTerms}</Text></View>
          {doc.shippingMark ? <View style={pdfStyles.line}><Text style={pdfStyles.label}>SHIPPING MARK :</Text><Text>{doc.shippingMark}</Text></View> : null}
        </View>

        <View style={pdfStyles.table}>
          <View style={pdfStyles.tr}>
            <Text style={[pdfStyles.th, pdfStyles.colDesc]}>DESCRIPTION OF GOODS</Text>
            <Text style={[pdfStyles.th, pdfStyles.colUnit]}>UNIT</Text>
            <Text style={[pdfStyles.th, pdfStyles.colQty]}>QTY</Text>
            <Text style={[pdfStyles.th, pdfStyles.colPrice]}>UNIT PRICE</Text>
            <Text style={[pdfStyles.th, pdfStyles.colAmt]}>AMOUNT</Text>
          </View>
          {items.map((it, i) => {
            const lineAmt = (it.qty || 0) * (it.unitPrice?.value || 0);
            return (
              <View key={i} style={pdfStyles.tr}>
                <Text style={[pdfStyles.td, pdfStyles.colDesc]}>{it.description}</Text>
                <Text style={[pdfStyles.td, pdfStyles.colUnit]}>{it.unit}</Text>
                <Text style={[pdfStyles.td, pdfStyles.colQty]}>{fmt(it.qty, 0)}</Text>
                <Text style={[pdfStyles.td, pdfStyles.colPrice]}>{`${it.unitPrice.currency} ${fmt(it.unitPrice.value)}`}</Text>
                <Text style={[pdfStyles.td, pdfStyles.colAmt]}>{`${it.unitPrice.currency} ${fmt(lineAmt)}`}</Text>
              </View>
            );
          })}
        </View>

        <View style={pdfStyles.summary}>
          <Text>SUBTOTAL: {fmtMoney(totals.subTotal)}</Text>
          <Text style={{ marginTop: 2 }}>GRAND TOTAL: {fmtMoney(totals.grandTotal)}</Text>
          <Text style={{ marginTop: 4 }}>Amount in words: {wordsAmount(totals.grandTotal)}</Text>
          {doc.minOrderQty?.value ? (<Text style={{ marginTop: 4 }}>MIN. QTY/ORDER: {fmt(doc.minOrderQty.value, 0)} {doc.minOrderQty.unit || ''}</Text>) : null}
          <Text style={{ marginTop: 4 }}>TERM OF PAYMENT: {doc.paymentTerms}</Text>
          {doc.sellerBank ? <Text style={{ marginTop: 2 }}>BANK DETAILS: {doc.sellerBank}</Text> : null}
          {typeof doc.fxRate === 'number' ? (<Text style={{ marginTop: 2 }}>EXCHANGE RATE: {fmt(doc.fxRate)}</Text>) : null}
          {doc.closing ? <Text style={{ marginTop: 6 }}>{doc.closing}</Text> : null}
        </View>

        <Text style={pdfStyles.footer}>Generated by Export Docs Webapp — {doc.docType}</Text>
      </Page>
    </Document>
  );
}

type Tab = 'Quotation' | 'Invoice' | 'History';
const EMPTY_DOC: CommonDoc = {
  docType: 'Quotation',
  docNo: 'QUO-2025-0001',
  subject: '',
  docDate: todayISO(),
  seller: { name: '', address: '' },
  buyer: { name: '', address: '' },
  attn: '',
  fromPerson: '',
  deliveryTerms: '',
  brand: '',
  paymentTerms: '',
  sellerBank: '',
  fxRate: undefined,
  closing: 'We appreciate your consideration and look forward to a long-term partnership.',
  shippingMark: '',
  items: [
    { description: 'Coconut Blossom Juice 250 ml (24 bottles/ctn)', unit: 'CTN', qty: 288, unitPrice: { currency: 'USD', value: 15.8 } },
  ],
  minOrderQty: { value: 288, unit: 'CTN' },
  exchangeCurrency: 'USD',
};

function useAutosave<T>(key: string, initial: T) {
  const [state, setState] = useState<T>(() => {
    try { const raw = localStorage.getItem(key); if (raw) return JSON.parse(raw) } catch {}
    return initial;
  });
  useEffect(() => {
    const id = setTimeout(() => localStorage.setItem(key, JSON.stringify(state)), 400);
    return () => clearTimeout(id);
  }, [key, state]);
  return [state, setState] as const;
}

function Label({ children }: { children: React.ReactNode }) { return <label className="label">{children}</label> }
function Input(props: React.InputHTMLAttributes<HTMLInputElement> & { right?: React.ReactNode }) {
  const { right, ...rest } = props; return (
    <div style={{ position: 'relative' }}>
      <input {...rest} className={'input ' + (props.className||'')} />
      {right && <div style={{position:'absolute', right:8, top:0, bottom:0, display:'flex', alignItems:'center'}} className="muted">{right}</div>}
    </div>
  )
}
function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) { return <textarea {...props} className={'input ' + (props.className||'')} /> }
function Select({ value, onChange, options, placeholder }: { value?: string; onChange: (v: string)=>void; options: string[]; placeholder?: string; }) {
  return (<select value={value} onChange={(e)=>onChange(e.target.value)} className="input">
    <option value="">{placeholder || 'Select...'}</option>
    {options.map(o => <option key={o} value={o}>{o}</option>)}
  </select>)
}
function Card({ title, children, className='' }: { title?: string; children: React.ReactNode; className?: string }) {
  return (<div className={'card ' + className}>
    {title && <div style={{marginBottom: 8}} className="label">{title}</div>}
    {children}
  </div>)
}

function LineItemsEditor({ items, onChange, currency, onCurrency }: {
  items: LineItem[]; onChange: (items: LineItem[]) => void; currency: Currency; onCurrency: (c: Currency)=>void;
}) {
  const update = (idx: number, patch: Partial<LineItem>) => {
    const next = items.slice();
    next[idx] = { ...next[idx], ...patch };
    onChange(next);
  };
  const add = () => onChange([...items, { description: '', unit: 'CTN', qty: 0, unitPrice: { currency, value: 0 } }]);
  const remove = (idx: number) => onChange(items.filter((_, i) => i !== idx));

  return (
    <div className="grid" style={{ gap: 12 }}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <Label>รายการสินค้า / Line Items</Label>
        <div className="row" style={{ fontSize: 12 }}>
          <span>Currency:&nbsp;</span>
          <select value={currency} onChange={(e)=>onCurrency(e.target.value)} className="input" style={{ width: 100 }}>
            {['USD','THB','EUR','AED'].map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>

      <div className="row muted" style={{ fontWeight: 600 }}>
        <div style={{ flex: 5 }}>DESCRIPTION OF GOODS</div>
        <div style={{ flex: 2 }}>UNIT</div>
        <div style={{ flex: 2, textAlign: 'right' }}>QTY</div>
        <div style={{ flex: 2, textAlign: 'right' }}>UNIT PRICE</div>
        <div style={{ width: 28 }} />
      </div>

      {items.map((it, i) => (
        <div key={i} className="row">
          <Input style={{ flex: 5 }} placeholder="e.g., Coconut Blossom Juice 250 ml (24 bottles/ctn)" value={it.description} onChange={(e)=>update(i,{ description: e.target.value })} />
          <Input style={{ flex: 2 }} value={it.unit} onChange={(e)=>update(i,{ unit: e.target.value })} />
          <Input className="right" style={{ flex: 2 }} type="number" value={Number.isFinite(it.qty) ? it.qty : 0} onChange={(e)=>update(i,{ qty: Number(e.target.value ?? 0) || 0 })} />
          <Input className="right" style={{ flex: 2 }} type="number" value={Number.isFinite(it.unitPrice?.value) ? it.unitPrice.value : 0} onChange={(e)=>update(i,{ unitPrice: { currency, value: Number(e.target.value ?? 0) || 0 } })} right={<span style={{ fontSize: 12 }}>{currency}</span>} />
          <button className="btn" onClick={()=>remove(i)} aria-label="Remove line"><Trash2 size={16}/></button>
        </div>
      ))}

      <div><button className="btn primary" onClick={add}><Plus size={16}/> Add line</button></div>
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState<Tab>('Quotation');
  const [doc, setDoc] = useAutosave<CommonDoc>(STORAGE_KEY, EMPTY_DOC);

  const docNoLabel = doc.docType === 'Quotation' ? 'OUR REF.' : 'INVOICE NO.';
  const totals = useMemo(() => computeTotals(doc.items, doc.exchangeCurrency || doc.items[0]?.unitPrice?.currency || 'USD'), [doc.items, doc.exchangeCurrency]);

  const requiredOk = useMemo(() => {
    const okBasics = !!doc.seller?.name && !!doc.seller?.address && !!doc.buyer?.name && !!doc.buyer?.address && !!doc.attn && !!doc.fromPerson && !!doc.subject && !!doc.deliveryTerms && !!doc.paymentTerms && (doc.items?.length || 0) > 0;
    return okBasics;
  }, [doc]);

  const onGeneratePDF = async () => {
    const blob = await pdf(<QuotationInvoicePDF doc={doc} />).toBlob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const prefix = doc.docType === 'Quotation' ? 'QUO' : 'INV';
    a.download = `${prefix}-${doc.docDate}-${(doc.docNo || '').replace(/\s+/g,'_') || 'doc'}.pdf`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const onSaveSheets = async () => {
    const current = doc;
    const res = await saveRowToSheets(current);
    setDoc((prev) => ({ ...prev, sheetRowId: res.sheetRowId }));
  };

  const onUploadDrive = async () => {
    const current = doc;
    const blob = await pdf(<QuotationInvoicePDF doc={current} />).toBlob();
    const prefix = current.docType === 'Quotation' ? 'QUO' : 'INV';
    const filename = `${prefix}-${current.docDate}-${(current.docNo || '').replace(/\s+/g,'_') || 'doc'}.pdf`;
    const res = await uploadPdfToDrive(blob, filename);
    setDoc((prev) => ({ ...prev, drivePdfUrl: res.webViewLink }));
  };

  return (
    <div style={{ minHeight: '100vh', padding: 24, backgroundColor: ivory }}>
      <div style={{ maxWidth: 1120, margin: '0 auto' }}>
        <div className="row" style={{ justifyContent: 'space-between', marginBottom: 24 }}>
          <div>
            <h1 style={{ margin: 0 }}>Export Docs Webapp</h1>
            <div className="muted">Create Quotation & Invoice • PDF Export • (Google Drive/Sheets: TODO)</div>
          </div>
          <div className="row">
            <button className="btn" onClick={googleSignIn}>Sign in with Google</button>
          </div>
        </div>

        <div className="row" style={{ gap: 8, marginBottom: 12 }}>
          {(['Quotation','Invoice','History'] as Tab[]).map(t => (
            <button key={t} onClick={()=>{
              setTab(t);
              setDoc(prev => ({
                ...prev,
                docType: t === 'History' ? prev.docType : (t as any),
                docNo: t === 'Invoice' ? 'INV-2025-0001' : (prev.docNo?.startsWith('INV-') ? 'QUO-2025-0001' : prev.docNo)
              }));
            }} className={'btn ' + (tab===t ? 'primary' : '')}>
              {t === 'Quotation' && <FileText size={16}/>}
              {t === 'Invoice' && <FileSignature size={16}/>}
              {t === 'History' && <History size={16}/>}
              &nbsp;{t}
            </button>
          ))}
        </div>

        {tab !== 'History' ? (
          <div className="grid" style={{ gridTemplateColumns: '1fr 380px', gap: 16 }}>
            <div className="grid" style={{ gap: 16 }}>
              <Card title="Parties & Metadata">
                <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="grid" style={{ gap: 8 }}>
                    <Label>ชื่อและที่อยู่ของผู้ส่งออก (SELLER)</Label>
                    <Input placeholder="Company name" value={doc.seller.name} onChange={(e)=>setDoc({ ...doc, seller: { ...doc.seller, name: e.target.value } })} />
                    <Textarea placeholder="Address" rows={3} value={doc.seller.address} onChange={(e)=>setDoc({ ...doc, seller: { ...doc.seller, address: e.target.value } })} />
                  </div>
                  <div className="grid" style={{ gap: 8 }}>
                    <Label>ชื่อและที่อยู่ของผู้ซื้อ (BUYER)</Label>
                    <Input placeholder="Buyer name" value={doc.buyer.name} onChange={(e)=>setDoc({ ...doc, buyer: { ...doc.buyer, name: e.target.value } })} />
                    <Textarea placeholder="Address" rows={3} value={doc.buyer.address} onChange={(e)=>setDoc({ ...doc, buyer: { ...doc.buyer, address: e.target.value } })} />
                  </div>

                  <div className="grid">
                    <Label>ATTN</Label>
                    <Input placeholder="ชื่อผู้รับ (ฝ่ายจัดซื้อ/นำเข้า)" value={doc.attn} onChange={(e)=>setDoc({ ...doc, attn: e.target.value })} />
                  </div>
                  <div className="grid">
                    <Label>FROM</Label>
                    <Input placeholder="ชื่อผู้ส่ง" value={doc.fromPerson} onChange={(e)=>setDoc({ ...doc, fromPerson: e.target.value })} />
                  </div>

                  <div className="grid" style={{ gridColumn: 'span 2' }}>
                    <Label>SUBJECT</Label>
                    <Input placeholder="หัวข้อหรือชื่อสินค้า" value={doc.subject} onChange={(e)=>setDoc({ ...doc, subject: e.target.value })} />
                  </div>

                  <div className="grid">
                    <Label>DATE</Label>
                    <Input type="date" value={doc.docDate} onChange={(e)=>setDoc({ ...doc, docDate: e.target.value })} />
                  </div>
                  <div className="grid">
                    <Label>{docNoLabel}</Label>
                    <Input placeholder={doc.docType==='Quotation'?'QUO-YYYY-####':'INV-YYYY-####'} value={doc.docNo} onChange={(e)=>setDoc({ ...doc, docNo: e.target.value })} />
                  </div>

                  <div className="grid" style={{ gridColumn: 'span 2' }}>
                    <Label>ตราสินค้า (Brand)</Label>
                    <Input placeholder="e.g., HuqKhuun" value={doc.brand || ''} onChange={(e)=>setDoc({ ...doc, brand: e.target.value })} />
                  </div>

                  <div className="grid" style={{ gridColumn: 'span 2' }}>
                    <Label>TERM OF DELIVERY (Incoterms)</Label>
                    <div className="row">
                      <Select value={doc.deliveryTerms} onChange={(v)=>setDoc({ ...doc, deliveryTerms: v })} options={incoterms} placeholder="Select preset" />
                      <Input placeholder="or type custom..." value={doc.deliveryTerms} onChange={(e)=>setDoc({ ...doc, deliveryTerms: e.target.value })} />
                    </div>
                  </div>

                  <div className="grid" style={{ gridColumn: 'span 2' }}>
                    <Label>TERM OF PAYMENT</Label>
                    <div className="row">
                      <Select value={doc.paymentTerms} onChange={(v)=>setDoc({ ...doc, paymentTerms: v })} options={paymentPresets} placeholder="Select preset" />
                      <Input placeholder="or type custom..." value={doc.paymentTerms} onChange={(e)=>setDoc({ ...doc, paymentTerms: e.target.value })} />
                    </div>
                  </div>

                  <div className="grid" style={{ gridColumn: 'span 2' }}>
                    <Label>รายละเอียดธนาคารของผู้ขาย (ถ้าชำระผ่านธนาคาร)</Label>
                    <Textarea rows={3} placeholder="Bank name, branch, SWIFT, account name/number" value={doc.sellerBank || ''} onChange={(e)=>setDoc({ ...doc, sellerBank: e.target.value })} />
                  </div>

                  <div className="grid">
                    <Label>Exchange Rate</Label>
                    <Input type="number" placeholder="e.g., 36.20" value={doc.fxRate ?? ''} onChange={(e)=>setDoc({ ...doc, fxRate: e.target.value === '' ? undefined : Number(e.target.value) })} />
                  </div>
                  <div className="grid">
                    <Label>คำลงท้าย / Closing</Label>
                    <Input value={doc.closing || ''} onChange={(e)=>setDoc({ ...doc, closing: e.target.value })} />
                  </div>

                  <div className="grid">
                    <Label>MIN. QTY/ORDER</Label>
                    <div className="row">
                      <Input type="number" placeholder="value" value={doc.minOrderQty?.value ?? 0} onChange={(e)=>setDoc({ ...doc, minOrderQty: { value: Number(e.target.value||'0') || 0, unit: doc.minOrderQty?.unit || 'CTN' } })} />
                      <Input placeholder="unit" value={doc.minOrderQty?.unit || 'CTN'} onChange={(e)=>setDoc({ ...doc, minOrderQty: { value: doc.minOrderQty?.value || 0, unit: e.target.value } })} />
                    </div>
                  </div>

                  <div className="grid">
                    <Label>Shipping Mark (optional)</Label>
                    <Input value={doc.shippingMark || ''} onChange={(e)=>setDoc({ ...doc, shippingMark: e.target.value })} />
                  </div>
                </div>
              </Card>

              <Card>
                <LineItemsEditor
                  items={doc.items}
                  onChange={(items)=>setDoc({ ...doc, items })}
                  currency={doc.exchangeCurrency || doc.items[0]?.unitPrice?.currency || 'USD'}
                  onCurrency={(c)=>{
                    const updated = doc.items.map(it => ({ ...it, unitPrice: { currency: c, value: it.unitPrice.value } }));
                    setDoc({ ...doc, exchangeCurrency: c, items: updated });
                  }}
                />
              </Card>

              <Card>
                <div className="row" style={{ justifyContent: 'space-between' }}>
                  <div className="muted">
                    <div>SUBTOTAL: <b>{fmtMoney(totals.subTotal)}</b></div>
                    <div>GRAND TOTAL: <b>{fmtMoney(totals.grandTotal)}</b></div>
                  </div>
                  <div className="row">
                    <button className="btn" onClick={onSaveSheets}><FileCheck2 size={16}/> Save to Sheets</button>
                    <button className="btn primary" onClick={onGeneratePDF} disabled={!requiredOk}><Download size={16}/> Export PDF</button>
                    <button className="btn" onClick={onUploadDrive}><Download size={16}/> Upload to Drive</button>
                  </div>
                </div>
                {!requiredOk && <p className="muted">กรุณากรอกฟิลด์บังคับให้ครบ (Seller/Buyer/ATTN/FROM/Subject/Incoterms/Payment/Line items)</p>}
              </Card>
            </div>

            <div className="grid" style={{ gap: 16 }}>
              <Card title="Preview (Summary)">
                <div className="grid" style={{ gap: 8, fontSize: 14 }}>
                  <div><b>{doc.docType}</b> • {doc.docDate} • {doc.docNo || '-'}</div>
                  <div className="muted">{doc.subject || '—'}</div>
                  <div className="card" style={{ padding: 8 }}>
                    <div className="muted">SELLER</div>
                    <div><b>{doc.seller.name || '—'}</b></div>
                    <div className="muted">{doc.seller.address || '—'}</div>
                  </div>
                  <div className="card" style={{ padding: 8 }}>
                    <div className="muted">BUYER</div>
                    <div><b>{doc.buyer.name || '—'}</b></div>
                    <div className="muted">{doc.buyer.address || '—'}</div>
                  </div>
                  <div className="muted">Totals</div>
                  <div><b>{fmtMoney(totals.grandTotal)}</b></div>
                  {typeof doc.fxRate === 'number' && (<div className="muted">FX: {fmt(doc.fxRate)}</div>)}
                </div>
              </Card>
              <div className="muted">* PDF preview will render when exporting. (Live PDF pane optional)</div>
            </div>
          </div>
        ) : (
          <Card title="History (Sheets)">
            <p className="muted">จะเชื่อมต่อ Google Sheets เพื่อดึงรายการเอกสารย้อนหลัง (ค้นหาตาม buyer/subject/date) — TODO</p>
            <div style={{ marginTop: 8 }}>
              <button className="btn">Connect Sheets</button>
            </div>
          </Card>
        )}

        <div style={{ marginTop: 32, textAlign: 'center' }} className="muted">© {new Date().getFullYear()} Export Docs Webapp MVP • Quotation & Invoice</div>
      </div>
    </div>
  );
}
